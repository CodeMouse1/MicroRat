var hal__digital__io_8h =
[
    [ "LEDState", "hal__digital__io_8h.html#a51a69e0b98357e170e63bc843e2fd1c0", [
      [ "off", "hal__digital__io_8h.html#a51a69e0b98357e170e63bc843e2fd1c0a53ace14c115e45153a1c9105accceb4c", null ],
      [ "on", "hal__digital__io_8h.html#a51a69e0b98357e170e63bc843e2fd1c0af3be4933da71233c5904ec919ac1fdb0", null ],
      [ "toggle", "hal__digital__io_8h.html#a51a69e0b98357e170e63bc843e2fd1c0a092819a2032e8d9810e80313491acd21", null ]
    ] ],
    [ "GetButtonInput", "hal__digital__io_8h.html#a1e6463c2e0b3ecd19d0293df81828ff0", null ],
    [ "SetLEDs", "hal__digital__io_8h.html#a81e126923c81b3b93196c081c9c43ac7", null ]
];