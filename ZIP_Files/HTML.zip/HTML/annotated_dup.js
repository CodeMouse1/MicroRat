var annotated_dup =
[
    [ "Cell", "struct_cell.html", null ],
    [ "IrCalibrationPoint", "struct_ir_calibration_point.html", null ],
    [ "PdLogEntry", "struct_pd_log_entry.html", null ],
    [ "ShortestPathMove", "struct_shortest_path_move.html", null ]
];