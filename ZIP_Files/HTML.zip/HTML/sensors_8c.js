var sensors_8c =
[
    [ "IrCalibrationPoint", "struct_ir_calibration_point.html", null ],
    [ "GetDistanceFront_mm", "sensors_8c.html#aed13fe27851df6349357ddf0e7de0349", null ],
    [ "GetDistanceLeft_mm", "sensors_8c.html#a7b8cb9a3528307c4b0aac1260765089a", null ],
    [ "GetDistanceRight_mm", "sensors_8c.html#a7d4ddbc7abad1b853fd6ba65c05f4163", null ],
    [ "GetEncoderLeft_mm", "sensors_8c.html#a3936e86db4d6979b22139c63f39253fa", null ],
    [ "GetEncoderRight_mm", "sensors_8c.html#a7aefb85ee6947ec2fdc52fc7faeae029", null ],
    [ "IsWallFront", "sensors_8c.html#ad8f13dee4d317f8616281b2226726008", null ],
    [ "IsWallLeft", "sensors_8c.html#adab7236d9f3bbf9cdd33bbb3548d2471", null ],
    [ "IsWallRight", "sensors_8c.html#a63f563ed31bf1b04c8ed76f095f71b00", null ],
    [ "PerformDiagnosticCheck", "sensors_8c.html#a159f45b12d777fcb7e454227d8024fd1", null ],
    [ "Sensors_Init", "sensors_8c.html#a2bea6c482debd3a4143b8e05665d517e", null ],
    [ "SensorsPrint", "sensors_8c.html#a63f2adb178546a701671bdb4a44b9424", null ],
    [ "ir_distance_lut", "sensors_8c.html#acc46e4b97df4c911d391685a3dbc40a3", null ]
];