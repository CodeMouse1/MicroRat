var movement_8c =
[
    [ "EstimateCellSize", "movement_8c.html#a429f6743ce3ae7c768cf00c2b72ebfe0", null ],
    [ "MoveMultipleCells", "movement_8c.html#a6a6f0c63e52038cd50a4fa567e198191", null ],
    [ "MoveOneCell", "movement_8c.html#a30bc79a9ecef336c833ae05b6ab739cd", null ],
    [ "Recalibrate", "movement_8c.html#aff4666dc9f1589f5655f2a5d30948a17", null ],
    [ "Stop", "movement_8c.html#a17a237457e57625296e6b24feb19c60a", null ],
    [ "Turn", "movement_8c.html#a920aa686909446236641a33cac442b6e", null ],
    [ "KP_STRAIGHT", "movement_8c.html#a2b6400321da3589f065d5657e23f8c3f", null ]
];