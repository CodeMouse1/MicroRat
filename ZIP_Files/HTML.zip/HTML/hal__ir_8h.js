var hal__ir_8h =
[
    [ "ReadLeft", "hal__ir_8h.html#a4eda8ab357024e1d31c62e833c584132", null ],
    [ "ReadRight", "hal__ir_8h.html#a1866ad800b9906795cf8d9ae43647764", null ]
];