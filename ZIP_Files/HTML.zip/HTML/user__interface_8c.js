var user__interface_8c =
[
    [ "IsStartButtonPressed", "user__interface_8c.html#ae1272fbbb50a069d5cb6826ba59f8ccb", null ],
    [ "SignalDiagnosticsResult", "user__interface_8c.html#aa4bc7dbed5d47db5c2212c9be34ad728", null ],
    [ "SignalOptimisationComplete", "user__interface_8c.html#a00acff9e97e6985fede5003a23d776c6", null ],
    [ "SignalOutOfBounds", "user__interface_8c.html#a55fae288f019fe66344d322192172c48", null ],
    [ "SignalTargetReached", "user__interface_8c.html#a4e15cb7b5797fd1a678fe8199741a672", null ]
];