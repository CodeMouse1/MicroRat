var hal__motor_8c =
[
    [ "MotorsSetSpeed", "hal__motor_8c.html#af853d72e2c79b261f64928af5b86cfb1", null ],
    [ "StopAndSignal", "hal__motor_8c.html#af9b127d7f21df69279ebc8b79540e544", null ],
    [ "currentMotorDirectionR", "hal__motor_8c.html#a27411c513b4ab2eab9936b1af5a0828c", null ]
];