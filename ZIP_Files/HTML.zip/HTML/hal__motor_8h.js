var hal__motor_8h =
[
    [ "MotorDirection", "hal__motor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0", [
      [ "MOTOR_STOPPED", "hal__motor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0a02c50778bea0b18671e7d446647c788a", null ],
      [ "MOTOR_FORWARD", "hal__motor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0af0f1281d2a842ac5b2cfcea0448dfe8d", null ],
      [ "MOTOR_BACKWARD", "hal__motor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0a5af0cbc39d4088d3c93dc6246f9fc048", null ]
    ] ],
    [ "MotorsSetSpeed", "hal__motor_8h.html#aa91f9c4482e74384aceaad6418686bc5", null ],
    [ "StopAndSignal", "hal__motor_8h.html#a5208b965441cf87e3342e144dbf30454", null ],
    [ "currentMotorDirectionR", "hal__motor_8h.html#a27411c513b4ab2eab9936b1af5a0828c", null ]
];