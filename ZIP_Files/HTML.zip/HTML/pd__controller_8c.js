var pd__controller_8c =
[
    [ "ClearPDLog", "pd__controller_8c.html#a1133cb59e4b65826313cac017f517853", null ],
    [ "ControllerHandler", "pd__controller_8c.html#a46a57229475f4e0a9cab3f6c9b0e9d7a", null ],
    [ "DumpPDLog", "pd__controller_8c.html#ae999b7259ea3239c837f724fe8e043a9", null ],
    [ "LogPDEntry", "pd__controller_8c.html#ae8311645714749efc299b17b9b920ac0", null ],
    [ "PDdone", "pd__controller_8c.html#abc50d95559db18316af62ea942506d0a", null ],
    [ "ResetPD", "pd__controller_8c.html#ab90a0c6ed215a9ce4b545fb872745f3b", null ],
    [ "setPDGoalD", "pd__controller_8c.html#afab01e37ca5b41a39a5e279539f98372", null ],
    [ "UpdatePD", "pd__controller_8c.html#abbed02185bc3d8b74f4b16d1c23bd189", null ],
    [ "distanceGoal_L", "pd__controller_8c.html#a478de24509c65ab603f31daa8a0a0076", null ],
    [ "last_abs_encoder_L", "pd__controller_8c.html#a0ea747c1063e1d18fc46d8ee929e208f", null ],
    [ "last_abs_encoder_R", "pd__controller_8c.html#a4fa4d1771797ecda284145211001dd8f", null ],
    [ "last_error_L", "pd__controller_8c.html#adf230d20f95a43d0ddacd87251eed801", null ],
    [ "last_error_R", "pd__controller_8c.html#ae73c02a99ba8d905eae3ad6c9b665864", null ],
    [ "last_pwmL_calculated", "pd__controller_8c.html#a2543a410f1d892ea3eb0fdceba5e8e42", null ],
    [ "last_pwmR_calculated", "pd__controller_8c.html#a1ea2a4fd11565cc0a4bf3eb69e86f86f", null ],
    [ "signed_current_pos_L", "pd__controller_8c.html#a5585d93efdd97b559e4d4b23331f1ad0", null ],
    [ "signed_current_pos_R", "pd__controller_8c.html#aa1e815ee875aa55c34e72bd223e88db1", null ],
    [ "UART_PD", "pd__controller_8c.html#a64321f88826a95f29f1cf47144fc9fb0", null ]
];