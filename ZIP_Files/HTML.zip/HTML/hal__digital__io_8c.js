var hal__digital__io_8c =
[
    [ "GetButtonInput", "hal__digital__io_8c.html#a1e6463c2e0b3ecd19d0293df81828ff0", null ],
    [ "SetLEDs", "hal__digital__io_8c.html#a81e126923c81b3b93196c081c9c43ac7", null ]
];