var debug__comms_8h =
[
    [ "Debug_Comms_SendBuffer", "debug__comms_8h.html#a9fd2381973c139a664fc930b0612c7e3", null ],
    [ "Debug_Comms_SendString", "debug__comms_8h.html#ad3acc201794880cf66d1a63f37b4c4be", null ]
];