var hal__encoder_8c =
[
    [ "EncoderReadLeft", "hal__encoder_8c.html#a3c01bd3b3a25f45b0cd5c6b1480ed1c1", null ],
    [ "EncoderReadRight", "hal__encoder_8c.html#ae0a4feb02598e6544cc501d9713ef34a", null ],
    [ "EncoderReset", "hal__encoder_8c.html#a1f711fe1ef258ba1b0d90cbce8a0e645", null ],
    [ "EncoderStartLeft", "hal__encoder_8c.html#a5766730a499876b1a93540d4b047a4f9", null ],
    [ "EncoderStartRight", "hal__encoder_8c.html#a05e7af77770ac07e978b006276f7b184", null ]
];