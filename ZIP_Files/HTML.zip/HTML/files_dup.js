var files_dup =
[
    [ "Applikation", "dir_a5c246a957f6c2390cab4c75d34198db.html", "dir_a5c246a957f6c2390cab4c75d34198db" ],
    [ "Funktionsschnittstellen", "dir_5037b92bc604720d4d9f1e8cde433116.html", "dir_5037b92bc604720d4d9f1e8cde433116" ],
    [ "Hardwaresteuerung", "dir_f77fb96e6fc71f3aac5fd48524e5b103.html", "dir_f77fb96e6fc71f3aac5fd48524e5b103" ]
];