var hal__timer_8c =
[
    [ "Delay_Blocking_ms", "hal__timer_8c.html#aa0fe3aa3779f528e2094cfafe3f7a2b0", null ],
    [ "PDTimer_Start", "hal__timer_8c.html#afc796f337691ecaa2f1a42246e6562cc", null ],
    [ "PDTimer_Stop", "hal__timer_8c.html#a2e7a646b341244183d3fd94cae51136c", null ],
    [ "TIMER_DELAY_ISR", "hal__timer_8c.html#abb56df03356c8738088331cc6e79bc25", null ]
];