var hal__timer_8h =
[
    [ "Delay_Blocking_ms", "hal__timer_8h.html#aa0fe3aa3779f528e2094cfafe3f7a2b0", null ],
    [ "PDTimer_Start", "hal__timer_8h.html#a27c5d0af618b241499e3158157e9a6e5", null ],
    [ "PDTimer_Stop", "hal__timer_8h.html#a3574e595dce0723fdc31036bf149c004", null ]
];