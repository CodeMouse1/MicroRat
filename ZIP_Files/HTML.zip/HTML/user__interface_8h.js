var user__interface_8h =
[
    [ "IsStartButtonPressed", "user__interface_8h.html#ae1272fbbb50a069d5cb6826ba59f8ccb", null ],
    [ "SignalDiagnosticsResult", "user__interface_8h.html#aa4bc7dbed5d47db5c2212c9be34ad728", null ],
    [ "SignalOptimisationComplete", "user__interface_8h.html#a6ed937234a3923b92b31d7991995c357", null ],
    [ "SignalOutOfBounds", "user__interface_8h.html#a995d435640589776461f7ca4bb18fbb8", null ],
    [ "SignalTargetReached", "user__interface_8h.html#aeefe744b109383ce292be3840e03d3b0", null ]
];