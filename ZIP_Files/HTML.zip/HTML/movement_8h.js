var movement_8h =
[
    [ "DISTANCE_PER_90_DEGREE_MM", "movement_8h.html#a0f6920d4262c4d910d6028ff45ccc139", null ],
    [ "MAX_MEASUREMENT_DISTANCE", "movement_8h.html#a93817d5af05876eb0938179bb0ef48dd", null ],
    [ "MIN_WALL_DISTANCE", "movement_8h.html#a00c7d10d52d119157556a0fc0d370f86", null ],
    [ "MM_PER_CELL_REFERENCE", "movement_8h.html#a93a029d1bee73d2034b27749cde3d1a9", null ],
    [ "ROBOT_WHEEL_BASE_MM", "movement_8h.html#aea2dc2ce10911678eb057ab4bbdb5f39", null ],
    [ "TurnDirection", "movement_8h.html#aa3ffc99db6424fdcb4ff7e9bb5f57108", [
      [ "none", "movement_8h.html#aa3ffc99db6424fdcb4ff7e9bb5f57108ab7e4e0120a041dbe6528b050c04269e0", null ],
      [ "left", "movement_8h.html#aa3ffc99db6424fdcb4ff7e9bb5f57108ab0ac36b187aa60c167ffcead3d5a03c0", null ],
      [ "right", "movement_8h.html#aa3ffc99db6424fdcb4ff7e9bb5f57108af763d610923b0c4614e8ecd65212666a", null ],
      [ "around", "movement_8h.html#aa3ffc99db6424fdcb4ff7e9bb5f57108a9c438aee81b20260c8d15ce1533ffb7f", null ]
    ] ],
    [ "EstimateCellSize", "movement_8h.html#acd11a0429092eb13ff7453a2764802ca", null ],
    [ "MoveMultipleCells", "movement_8h.html#a6a6f0c63e52038cd50a4fa567e198191", null ],
    [ "MoveOneCell", "movement_8h.html#a9c246bf6d514207fa5c9d4f4c195adb3", null ],
    [ "Recalibrate", "movement_8h.html#a0e730a88247f5cb1ef6b178bd6ce0303", null ],
    [ "Stop", "movement_8h.html#a76c658dc5f4332e4b034419dca518c1c", null ],
    [ "Turn", "movement_8h.html#a920aa686909446236641a33cac442b6e", null ]
];