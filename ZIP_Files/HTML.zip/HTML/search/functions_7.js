var searchData=
[
  ['logpdentry_0',['LogPDEntry',['../pd__controller_8c.html#ae8311645714749efc299b17b9b920ac0',1,'LogPDEntry(float error_L, float error_R, float correction_L, float correction_R, float current_pos_L, float current_pos_R, int is_stable_condition_met):&#160;pd_controller.c'],['../pd__controller_8h.html#ae8311645714749efc299b17b9b920ac0',1,'LogPDEntry(float error_L, float error_R, float correction_L, float correction_R, float current_pos_L, float current_pos_R, int is_stable_condition_met):&#160;pd_controller.c']]]
];
