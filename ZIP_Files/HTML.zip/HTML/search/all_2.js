var searchData=
[
  ['debug_5fcomms_2ec_0',['debug_comms.c',['../debug__comms_8c.html',1,'']]],
  ['debug_5fcomms_2eh_1',['debug_comms.h',['../debug__comms_8h.html',1,'']]],
  ['debug_5fcomms_5fsendbuffer_2',['Debug_Comms_SendBuffer',['../debug__comms_8c.html#a9fd2381973c139a664fc930b0612c7e3',1,'Debug_Comms_SendBuffer(const uint8_t *data, size_t length):&#160;debug_comms.c'],['../debug__comms_8h.html#a9fd2381973c139a664fc930b0612c7e3',1,'Debug_Comms_SendBuffer(const uint8_t *data, size_t length):&#160;debug_comms.c']]],
  ['debug_5fcomms_5fsendstring_3',['Debug_Comms_SendString',['../debug__comms_8c.html#ad3acc201794880cf66d1a63f37b4c4be',1,'Debug_Comms_SendString(const char *str):&#160;debug_comms.c'],['../debug__comms_8h.html#ad3acc201794880cf66d1a63f37b4c4be',1,'Debug_Comms_SendString(const char *str):&#160;debug_comms.c']]],
  ['delay_5fblocking_5fms_4',['Delay_Blocking_ms',['../hal__timer_8c.html#aa0fe3aa3779f528e2094cfafe3f7a2b0',1,'Delay_Blocking_ms(uint32_t milliseconds):&#160;hal_timer.c'],['../hal__timer_8h.html#aa0fe3aa3779f528e2094cfafe3f7a2b0',1,'Delay_Blocking_ms(uint32_t milliseconds):&#160;hal_timer.c']]],
  ['delay_5fms_5',['Delay_ms',['../system__interface_8c.html#a14c78822167012f0af4f073eb33f00e7',1,'Delay_ms(uint32_t milliseconds):&#160;system_interface.c'],['../system__interface_8h.html#a14c78822167012f0af4f073eb33f00e7',1,'Delay_ms(uint32_t milliseconds):&#160;system_interface.c']]],
  ['distance_5fper_5f90_5fdegree_5fmm_6',['DISTANCE_PER_90_DEGREE_MM',['../movement_8h.html#a0f6920d4262c4d910d6028ff45ccc139',1,'movement.h']]],
  ['distancegoal_5fl_7',['distanceGoal_L',['../pd__controller_8c.html#a478de24509c65ab603f31daa8a0a0076',1,'pd_controller.c']]],
  ['distancemap_8',['distanceMap',['../maze_8c.html#ae6fd94333fe813c0a6b009586155bd98',1,'distanceMap:&#160;maze.c'],['../maze_8h.html#ae6fd94333fe813c0a6b009586155bd98',1,'distanceMap:&#160;maze.c']]],
  ['dumppdlog_9',['DumpPDLog',['../pd__controller_8c.html#ae999b7259ea3239c837f724fe8e043a9',1,'DumpPDLog(void):&#160;pd_controller.c'],['../pd__controller_8h.html#ae999b7259ea3239c837f724fe8e043a9',1,'DumpPDLog(void):&#160;pd_controller.c']]]
];
