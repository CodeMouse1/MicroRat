var searchData=
[
  ['signed_5fcurrent_5fpos_5fl_0',['signed_current_pos_L',['../pd__controller_8c.html#a5585d93efdd97b559e4d4b23331f1ad0',1,'pd_controller.c']]],
  ['signed_5fcurrent_5fpos_5fr_1',['signed_current_pos_R',['../pd__controller_8c.html#aa1e815ee875aa55c34e72bd223e88db1',1,'pd_controller.c']]]
];
