var searchData=
[
  ['hal_5fuart_5fsendbuffer_0',['HAL_UART_SendBuffer',['../hal__uart_8c.html#aa86fafffa0e0fb3410d9564fa721da60',1,'HAL_UART_SendBuffer(const uint8_t *data, uint32_t length):&#160;hal_uart.c'],['../hal__uart_8h.html#aa86fafffa0e0fb3410d9564fa721da60',1,'HAL_UART_SendBuffer(const uint8_t *data, uint32_t length):&#160;hal_uart.c']]]
];
