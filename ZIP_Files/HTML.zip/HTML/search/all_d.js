var searchData=
[
  ['pathfinding_2ec_0',['pathfinding.c',['../pathfinding_8c.html',1,'']]],
  ['pathfinding_2eh_1',['pathfinding.h',['../pathfinding_8h.html',1,'']]],
  ['pathfinding_5fcalculatedistancemap_2',['Pathfinding_CalculateDistanceMap',['../pathfinding_8c.html#a4e8a46d5d778fb74efb4bc83f04cc76b',1,'Pathfinding_CalculateDistanceMap(int targetX_param, int targetY_param):&#160;pathfinding.c'],['../pathfinding_8h.html#ac92ee2ad4882a25ff3ccc30f84d17a3f',1,'Pathfinding_CalculateDistanceMap(int targetX, int targetY):&#160;pathfinding.c']]],
  ['pathfinding_5fexecuteshortestpath_3',['Pathfinding_ExecuteShortestPath',['../pathfinding_8c.html#a9eb582a6c3f485ba261960107c722cb9',1,'Pathfinding_ExecuteShortestPath(void):&#160;pathfinding.c'],['../pathfinding_8h.html#a9eb582a6c3f485ba261960107c722cb9',1,'Pathfinding_ExecuteShortestPath(void):&#160;pathfinding.c']]],
  ['pathfinding_5fgetneworientation_4',['Pathfinding_GetNewOrientation',['../pathfinding_8c.html#a142953a1a0f0fe592ddd3b5be18b7739',1,'Pathfinding_GetNewOrientation(Orientation current_orientation, TurnMouse turn):&#160;pathfinding.c'],['../pathfinding_8h.html#a142953a1a0f0fe592ddd3b5be18b7739',1,'Pathfinding_GetNewOrientation(Orientation current_orientation, TurnMouse turn):&#160;pathfinding.c']]],
  ['pathfinding_5fgetnextshortestpathmove_5',['Pathfinding_GetNextShortestPathMove',['../pathfinding_8c.html#a3f14abcd90792f5f70a1ba476c440e9c',1,'Pathfinding_GetNextShortestPathMove(int currentX_param, int currentY_param, Orientation currentOrientation_param):&#160;pathfinding.c'],['../pathfinding_8h.html#ac31f559b35b2a1f4d4a1559ea5249267',1,'Pathfinding_GetNextShortestPathMove(int currentX, int currentY, Orientation currentOrientation):&#160;pathfinding.c']]],
  ['pathfinding_5fwallfollower_6',['Pathfinding_Wallfollower',['../pathfinding_8c.html#a74ed9ea7ce89427036ed0bac5a51a8eb',1,'Pathfinding_Wallfollower(WallfollowMode mode):&#160;pathfinding.c'],['../pathfinding_8h.html#a74ed9ea7ce89427036ed0bac5a51a8eb',1,'Pathfinding_Wallfollower(WallfollowMode mode):&#160;pathfinding.c']]],
  ['pd_5fcontroller_2ec_7',['pd_controller.c',['../pd__controller_8c.html',1,'']]],
  ['pd_5fcontroller_2eh_8',['pd_controller.h',['../pd__controller_8h.html',1,'']]],
  ['pddone_9',['PDdone',['../pd__controller_8c.html#abc50d95559db18316af62ea942506d0a',1,'PDdone():&#160;pd_controller.c'],['../pd__controller_8h.html#ae4c1c63b0f5be4c67328ae27ed36d078',1,'PDdone(void):&#160;pd_controller.c']]],
  ['pdlogentry_10',['PdLogEntry',['../struct_pd_log_entry.html',1,'']]],
  ['pdtimer_5fstart_11',['PDTimer_Start',['../hal__timer_8c.html#afc796f337691ecaa2f1a42246e6562cc',1,'PDTimer_Start():&#160;hal_timer.c'],['../hal__timer_8h.html#a27c5d0af618b241499e3158157e9a6e5',1,'PDTimer_Start(void):&#160;hal_timer.c']]],
  ['pdtimer_5fstop_12',['PDTimer_Stop',['../hal__timer_8c.html#a2e7a646b341244183d3fd94cae51136c',1,'PDTimer_Stop():&#160;hal_timer.c'],['../hal__timer_8h.html#a3574e595dce0723fdc31036bf149c004',1,'PDTimer_Stop(void):&#160;hal_timer.c']]],
  ['performdiagnosticcheck_13',['PerformDiagnosticCheck',['../sensors_8c.html#a159f45b12d777fcb7e454227d8024fd1',1,'PerformDiagnosticCheck(void):&#160;sensors.c'],['../sensors_8h.html#a159f45b12d777fcb7e454227d8024fd1',1,'PerformDiagnosticCheck(void):&#160;sensors.c']]],
  ['plattform_14',['MicroRat: Eine autonome Micromouse-Plattform',['../index.html',1,'']]],
  ['pwm_5fmax_15',['PWM_MAX',['../pd__controller_8h.html#a391fa1e490bd712720989b58fa0d9904',1,'pd_controller.h']]]
];
