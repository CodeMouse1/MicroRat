var searchData=
[
  ['pdlogentry_0',['PdLogEntry',['../struct_pd_log_entry.html',1,'']]]
];
