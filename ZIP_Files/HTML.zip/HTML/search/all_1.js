var searchData=
[
  ['cell_0',['Cell',['../struct_cell.html',1,'']]],
  ['clearpdlog_1',['ClearPDLog',['../pd__controller_8c.html#a1133cb59e4b65826313cac017f517853',1,'ClearPDLog(void):&#160;pd_controller.c'],['../pd__controller_8h.html#a1133cb59e4b65826313cac017f517853',1,'ClearPDLog(void):&#160;pd_controller.c']]],
  ['controllerhandler_2',['ControllerHandler',['../pd__controller_8c.html#a46a57229475f4e0a9cab3f6c9b0e9d7a',1,'pd_controller.c']]],
  ['currentmotordirectionr_3',['currentMotorDirectionR',['../hal__motor_8c.html#a27411c513b4ab2eab9936b1af5a0828c',1,'currentMotorDirectionR:&#160;hal_motor.c'],['../hal__motor_8h.html#a27411c513b4ab2eab9936b1af5a0828c',1,'currentMotorDirectionR:&#160;hal_motor.c']]],
  ['currentorientation_4',['currentOrientation',['../pathfinding_8h.html#aa4f63de578b5010162c358a1ab1ddd37',1,'currentOrientation:&#160;state_machine.c'],['../state__machine_8c.html#aa4f63de578b5010162c358a1ab1ddd37',1,'currentOrientation:&#160;state_machine.c']]],
  ['currentstate_5',['currentState',['../state__machine_8c.html#a7c0f3dc5c9707e80943d3f6d8f0d4c35',1,'currentState:&#160;state_machine.c'],['../state__machine_8h.html#a7c0f3dc5c9707e80943d3f6d8f0d4c35',1,'currentState:&#160;state_machine.c']]],
  ['currenty_6',['currentY',['../pathfinding_8h.html#af649605bffa9661bfdf81cb40fcbccbd',1,'currentY:&#160;state_machine.c'],['../state__machine_8c.html#af649605bffa9661bfdf81cb40fcbccbd',1,'currentY:&#160;state_machine.c']]],
  ['cycles_5fthreshold_7',['CYCLES_THRESHOLD',['../pd__controller_8h.html#a991dfa8d199af55a5f6109392aaba509',1,'pd_controller.h']]]
];
