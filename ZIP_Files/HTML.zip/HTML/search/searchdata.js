var indexSectionsWithContent =
{
  0: "acdefghiklmnopqrstuw",
  1: "cips",
  2: "dhmpsu",
  3: "cdefghilmprstu",
  4: "cdiklmstu",
  5: "lmortw",
  6: "cdkmnpqru",
  7: "aemp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Pages"
};

