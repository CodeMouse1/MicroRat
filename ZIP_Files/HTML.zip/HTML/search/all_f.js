var searchData=
[
  ['ratstate_0',['RatState',['../state__machine_8h.html#a3a5fe7f326df8b4535946c4e86103634',1,'state_machine.h']]],
  ['ratstatemachine_5fupdate_1',['RatStateMachine_Update',['../state__machine_8c.html#adc66120d2af7144c460858392e6219b8',1,'RatStateMachine_Update(void):&#160;state_machine.c'],['../state__machine_8h.html#adc66120d2af7144c460858392e6219b8',1,'RatStateMachine_Update(void):&#160;state_machine.c']]],
  ['readleft_2',['ReadLeft',['../hal__ir_8c.html#a4eda8ab357024e1d31c62e833c584132',1,'ReadLeft(void):&#160;hal_ir.c'],['../hal__ir_8h.html#a4eda8ab357024e1d31c62e833c584132',1,'ReadLeft(void):&#160;hal_ir.c']]],
  ['readright_3',['ReadRight',['../hal__ir_8c.html#a1866ad800b9906795cf8d9ae43647764',1,'ReadRight(void):&#160;hal_ir.c'],['../hal__ir_8h.html#a1866ad800b9906795cf8d9ae43647764',1,'ReadRight(void):&#160;hal_ir.c']]],
  ['recalibrate_4',['Recalibrate',['../movement_8c.html#aff4666dc9f1589f5655f2a5d30948a17',1,'Recalibrate():&#160;movement.c'],['../movement_8h.html#a0e730a88247f5cb1ef6b178bd6ce0303',1,'Recalibrate(void):&#160;movement.c']]],
  ['resetpd_5',['ResetPD',['../pd__controller_8c.html#ab90a0c6ed215a9ce4b545fb872745f3b',1,'ResetPD():&#160;pd_controller.c'],['../pd__controller_8h.html#a77ed610b514271197276703ab512472e',1,'ResetPD(void):&#160;pd_controller.c']]],
  ['robot_5fwheel_5fbase_5fmm_6',['ROBOT_WHEEL_BASE_MM',['../movement_8h.html#aea2dc2ce10911678eb057ab4bbdb5f39',1,'movement.h']]]
];
