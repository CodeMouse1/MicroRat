var searchData=
[
  ['unvisited_5fdistance_0',['UNVISITED_DISTANCE',['../maze_8h.html#a6db26044b12104abcd859fef89359554',1,'maze.h']]]
];
