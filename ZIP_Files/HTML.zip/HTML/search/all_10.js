var searchData=
[
  ['sensors_2ec_0',['sensors.c',['../sensors_8c.html',1,'']]],
  ['sensors_2eh_1',['sensors.h',['../sensors_8h.html',1,'']]],
  ['sensors_5finit_2',['Sensors_Init',['../sensors_8c.html#a2bea6c482debd3a4143b8e05665d517e',1,'Sensors_Init():&#160;sensors.c'],['../sensors_8h.html#a00954612fec82c4eca8d63d6d939b9c8',1,'Sensors_Init(void):&#160;sensors.c']]],
  ['sensorsprint_3',['SensorsPrint',['../sensors_8c.html#a63f2adb178546a701671bdb4a44b9424',1,'SensorsPrint():&#160;sensors.c'],['../sensors_8h.html#a5b82da44111ae59204c6b6269b11f8be',1,'SensorsPrint(void):&#160;sensors.c']]],
  ['setleds_4',['SetLEDs',['../hal__digital__io_8c.html#a81e126923c81b3b93196c081c9c43ac7',1,'SetLEDs(LEDState left, LEDState right):&#160;hal_digital_io.c'],['../hal__digital__io_8h.html#a81e126923c81b3b93196c081c9c43ac7',1,'SetLEDs(LEDState left, LEDState right):&#160;hal_digital_io.c']]],
  ['setpdgoald_5',['setPDGoalD',['../pd__controller_8c.html#afab01e37ca5b41a39a5e279539f98372',1,'setPDGoalD(float distance_R, float distance_L):&#160;pd_controller.c'],['../pd__controller_8h.html#afab01e37ca5b41a39a5e279539f98372',1,'setPDGoalD(float distance_R, float distance_L):&#160;pd_controller.c']]],
  ['shortestpathmove_6',['ShortestPathMove',['../struct_shortest_path_move.html',1,'']]],
  ['signaldiagnosticsresult_7',['SignalDiagnosticsResult',['../user__interface_8c.html#aa4bc7dbed5d47db5c2212c9be34ad728',1,'SignalDiagnosticsResult(bool result):&#160;user_interface.c'],['../user__interface_8h.html#aa4bc7dbed5d47db5c2212c9be34ad728',1,'SignalDiagnosticsResult(bool result):&#160;user_interface.c']]],
  ['signaloptimisationcomplete_8',['SignalOptimisationComplete',['../user__interface_8c.html#a00acff9e97e6985fede5003a23d776c6',1,'SignalOptimisationComplete():&#160;user_interface.c'],['../user__interface_8h.html#a6ed937234a3923b92b31d7991995c357',1,'SignalOptimisationComplete(void):&#160;user_interface.c']]],
  ['signaloutofbounds_9',['SignalOutOfBounds',['../user__interface_8c.html#a55fae288f019fe66344d322192172c48',1,'SignalOutOfBounds():&#160;user_interface.c'],['../user__interface_8h.html#a995d435640589776461f7ca4bb18fbb8',1,'SignalOutOfBounds(void):&#160;user_interface.c']]],
  ['signaltargetreached_10',['SignalTargetReached',['../user__interface_8c.html#a4e15cb7b5797fd1a678fe8199741a672',1,'SignalTargetReached():&#160;user_interface.c'],['../user__interface_8h.html#aeefe744b109383ce292be3840e03d3b0',1,'SignalTargetReached(void):&#160;user_interface.c']]],
  ['signed_5fcurrent_5fpos_5fl_11',['signed_current_pos_L',['../pd__controller_8c.html#a5585d93efdd97b559e4d4b23331f1ad0',1,'pd_controller.c']]],
  ['signed_5fcurrent_5fpos_5fr_12',['signed_current_pos_R',['../pd__controller_8c.html#aa1e815ee875aa55c34e72bd223e88db1',1,'pd_controller.c']]],
  ['startsensortimer_13',['StartSensorTimer',['../hal__encoder_8h.html#acf03ad76c7bdabe61e87783f407c6cab',1,'hal_encoder.h']]],
  ['state_5fmachine_2ec_14',['state_machine.c',['../state__machine_8c.html',1,'']]],
  ['state_5fmachine_2eh_15',['state_machine.h',['../state__machine_8h.html',1,'']]],
  ['stop_16',['Stop',['../movement_8c.html#a17a237457e57625296e6b24feb19c60a',1,'Stop():&#160;movement.c'],['../movement_8h.html#a76c658dc5f4332e4b034419dca518c1c',1,'Stop(void):&#160;movement.c']]],
  ['stopandsignal_17',['StopAndSignal',['../hal__motor_8c.html#af9b127d7f21df69279ebc8b79540e544',1,'StopAndSignal():&#160;hal_motor.c'],['../hal__motor_8h.html#a5208b965441cf87e3342e144dbf30454',1,'StopAndSignal(void):&#160;hal_motor.c']]],
  ['system_5finterface_2ec_18',['system_interface.c',['../system__interface_8c.html',1,'']]],
  ['system_5finterface_2eh_19',['system_interface.h',['../system__interface_8h.html',1,'']]]
];
