var searchData=
[
  ['ircalibrationpoint_0',['IrCalibrationPoint',['../struct_ir_calibration_point.html',1,'']]]
];
