#include "Dave.h"
#include "Dummy.h"
#include <stdio.h>

#define PERIODIC_READ 100000U

uint8_t UART_String[100];
uint32_t Timer_100ms;
uint32_t Capture_t;

XMC_VADC_RESULT_SIZE_t ADC_Wert_IR_L;
XMC_VADC_RESULT_SIZE_t ADC_Wert_IR_R;

float captured_time_us;
float distanz_ultra;
int IR_L, IR_R;

void Sensoren_Auslesen_100ms(void){
	//IR
	ADC_Wert_IR_R = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Channel_A);
	ADC_Wert_IR_L = ADC_MEASUREMENT_GetResult(&ADC_MEASUREMENT_Channel_B);
	IR_R = ADC_Wert_IR_R;
	IR_L = ADC_Wert_IR_L;
	//ULTRASCHALL
	CAPTURE_GetCapturedTime(&CAPTURE_ULTRA, &Capture_t);
	captured_time_us = ((float)Capture_t * 333.33)/1000;
	distanz_ultra = captured_time_us /58;
	//DREZAHL

	//UART-Transmit
	sprintf((char*)UART_String,	" Ultraschall: %.2fcm IR_R: %d IR_L: %d\n\r", distanz_ultra, IR_R, IR_L);
	UART_Transmit(&UART_COM, UART_String, sizeof(UART_String));

	DIGITAL_IO_ToggleOutput(&DIGITAL_IO_AUGE_1);
	DIGITAL_IO_ToggleOutput(&DIGITAL_IO_AUGE_2);

}

void Dummycode_Init(void)
{
	Timer_100ms = SYSTIMER_CreateTimer(PERIODIC_READ,SYSTIMER_MODE_PERIODIC,(void*)Sensoren_Auslesen_100ms,NULL);
	SYSTIMER_StartTimer(Timer_100ms);
}
