/*
 * Dummy.h
 *
 *  Created on: 27 Jun 2024
 *      Author: marcu
 */

#ifndef DUMMY_H_
#define DUMMY_H_

void Dummycode_Init(void);
void Sensoren_Auslesen_100ms(void);

#endif /* DUMMY_H_ */
