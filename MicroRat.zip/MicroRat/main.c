#include "DAVE.h"
#include "Dummy.h"

int button_status = 0;


int main(void)
{
	DAVE_Init();           /* Initialization of DAVE APPs  */
	//Dummycode_Init();

	while(true){
	button_status = DIGITAL_IO_GetInput(&DIGITAL_IO_BUTTON);
		if(button_status == 1){
			Dummycode_Init();
			button_status = 0;
		}
	}
}




