#include "DAVE.h"
#include "Dummy.h"

int button_status = 0;


int main(void)
{
	DAVE_Init();           /* Initialization of DAVE APPs  */

	while(true){
	button_status = DIGITAL_IO_GetInput(&DIGITAL_IO_BUTTON);
		if(button_status == 1){
			Dummycode_Init();
			button_status = 0;
		}
	}
}

void Event_L(void)
{
	DIGITAL_IO_ToggleOutput(&DIGITAL_IO_AUGE_1);

}
void Event_R(void)
{
	DIGITAL_IO_ToggleOutput(&DIGITAL_IO_AUGE_2);
}



